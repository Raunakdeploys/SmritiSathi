import React, { useState, useEffect, useRef } from 'react';
import {
  APIProvider,
  Map,
  Marker,
} from '@vis.gl/react-google-maps';
import {
  Navigation,
  Home,
  Layers,
  Share2,
  ExternalLink,
  Key,
  ShieldCheck,
  AlertTriangle,
  Radio,
  Compass,
  MapPin,
  CheckCircle,
  Copy,
  Plus,
  Minus,
  Maximize2,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import type {
  CareCompassTelemetry,
  CareCompassConfig,
  GeofenceZoneStatus,
  BreadcrumbPoint,
} from '../types';
import {
  INITIAL_CARE_COMPASS_CONFIG,
  INITIAL_CARE_COMPASS_TELEMETRY,
} from '../services/storeService';
import {
  calculateHaversineDistanceMeters,
  calculateBearingDegrees,
  degreesToCompassText,
  determineGeofenceStatus,
} from '../utils/geoUtils';

interface MapModuleProps {
  telemetry?: CareCompassTelemetry;
  config?: CareCompassConfig;
  onUpdateLocation?: (lat: number, lng: number) => void;
  onOpenKeyModal?: () => void;
  className?: string;
  isSimulating?: boolean;
}

type ViewMode = 'interactive_map' | 'radar_hud' | 'google_maps';
type TileStyle = 'dark' | 'satellite' | 'streets';

export const MapModule: React.FC<MapModuleProps> = ({
  telemetry: propTelemetry,
  config: propConfig,
  onUpdateLocation,
  onOpenKeyModal,
  className = '',
  isSimulating = false,
}) => {
  const telemetry = propTelemetry || INITIAL_CARE_COMPASS_TELEMETRY;
  const config = propConfig || INITIAL_CARE_COMPASS_CONFIG;

  const [apiKey, setApiKey] = useState<string>(() => {
    return (
      config.googleMapsApiKey ||
      (typeof window !== 'undefined'
        ? localStorage.getItem('cc_google_maps_api_key') || ''
        : '')
    );
  });

  const [viewMode, setViewMode] = useState<ViewMode>(apiKey ? 'google_maps' : 'interactive_map');
  const [tileStyle, setTileStyle] = useState<TileStyle>('dark');
  const [copiedLink, setCopiedLink] = useState(false);
  const [zoomScale, setZoomScale] = useState<number>(1);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Synchronize API key changes
  useEffect(() => {
    const handleStorageChange = () => {
      const stored = localStorage.getItem('cc_google_maps_api_key');
      if (stored !== null) {
        setApiKey(stored);
        if (stored) setViewMode('google_maps');
      }
    };
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('cc_maps_key_updated', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('cc_maps_key_updated', handleStorageChange);
    };
  }, []);

  const handleCenterOnPatient = () => {
    setPanOffset({ x: 0, y: 0 });
    setZoomScale(1.1);
  };

  const handleCenterOnHome = () => {
    setPanOffset({ x: 0, y: 0 });
    setZoomScale(1);
  };

  const handleShareLiveUrl = () => {
    const url = `https://maps.google.com/?q=${telemetry.latitude.toFixed(6)},${telemetry.longitude.toFixed(6)}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 3000);
    }
  };

  const openGoogleDirections = () => {
    const origin = `${telemetry.latitude},${telemetry.longitude}`;
    const destination = `${config.homeLocation.latitude},${config.homeLocation.longitude}`;
    window.open(
      `https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${destination}&travelmode=walking`,
      '_blank'
    );
  };

  const getStatusBadge = (status: GeofenceZoneStatus) => {
    switch (status) {
      case 'SAFE_ZONE':
        return {
          label: `SAFE ZONE (${config.safeRadiusMeters}m)`,
          bg: 'bg-emerald-600',
          border: 'border-emerald-400',
          text: 'text-emerald-100',
          icon: ShieldCheck,
        };
      case 'WARNING_BORDER':
        return {
          label: `WARNING BORDER (${config.alertRadiusMeters}m)`,
          bg: 'bg-amber-600',
          border: 'border-amber-400',
          text: 'text-amber-100',
          icon: AlertTriangle,
        };
      case 'CRITICAL_BREACH':
        return {
          label: 'CRITICAL PERIMETER BREACH',
          bg: 'bg-rose-600 animate-pulse',
          border: 'border-rose-400',
          text: 'text-rose-100',
          icon: Radio,
        };
    }
  };

  const statusBadge = getStatusBadge(telemetry.geofenceStatus);
  const StatusIcon = statusBadge.icon;

  return (
    <div
      id="carecompass-live-map-container"
      className={`relative w-full rounded-3xl overflow-hidden border-2 border-slate-700 bg-slate-900 shadow-2xl flex flex-col ${className}`}
    >
      {/* Top Map Toolbar */}
      <div className="bg-slate-900/95 backdrop-blur-md px-4 py-3.5 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 z-20">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-400 flex items-center justify-center shadow-inner">
            <Radio className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-black text-white flex items-center gap-2">
              <span>Live GPS Geofence Radar</span>
              {isSimulating && (
                <span className="text-[10px] font-extrabold uppercase tracking-wider bg-indigo-900/90 text-indigo-200 border border-indigo-500/50 px-2 py-0.5 rounded-full">
                  Simulation
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-400 flex items-center gap-1">
              <MapPin className="w-3 h-3 text-[#FF6321]" />
              <span>{config.homeLocation.city}</span>
              <span className="text-slate-600">•</span>
              <span className="truncate max-w-[200px]">{config.homeLocation.label}</span>
            </p>
          </div>
        </div>

        {/* Live Status Pill */}
        <div
          className={`flex items-center space-x-2 px-3.5 py-1.5 rounded-full border text-xs font-black shadow-md ${statusBadge.bg} ${statusBadge.border} ${statusBadge.text}`}
        >
          <StatusIcon className="w-4 h-4 shrink-0" />
          <span>{statusBadge.label}</span>
          <span className="font-mono text-xs opacity-90 pl-1">
            • {Math.round(telemetry.distanceMeters)}m
          </span>
        </div>

        {/* Map View & Layer Actions */}
        <div className="flex items-center space-x-1.5 flex-wrap">
          {/* Mode Switcher */}
          <div className="flex bg-slate-800 rounded-xl p-1 border border-slate-700 text-xs font-bold">
            <button
              onClick={() => setViewMode('interactive_map')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === 'interactive_map'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Interactive Map
            </button>
            <button
              onClick={() => setViewMode('radar_hud')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === 'radar_hud'
                  ? 'bg-[#002045] text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Tactical HUD
            </button>
            {apiKey && (
              <button
                onClick={() => setViewMode('google_maps')}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  viewMode === 'google_maps'
                    ? 'bg-sky-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Google Satellite
              </button>
            )}
          </div>

          <button
            onClick={handleCenterOnPatient}
            title="Center on Patient (Dadaji)"
            className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-slate-200 rounded-xl border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
          >
            <Navigation className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">Elder</span>
          </button>

          <button
            onClick={handleCenterOnHome}
            title="Center on Home Base"
            className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-slate-200 rounded-xl border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
          >
            <Home className="w-3.5 h-3.5 text-[#FF6321]" />
            <span className="hidden sm:inline">Home</span>
          </button>

          <button
            onClick={handleShareLiveUrl}
            title="Copy Live Google Maps Coordinates Link"
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 transition-all cursor-pointer"
          >
            {copiedLink ? (
              <CheckCircle className="w-4 h-4 text-emerald-400" />
            ) : (
              <Share2 className="w-4 h-4" />
            )}
          </button>

          <button
            onClick={openGoogleDirections}
            title="Open Turn-by-Turn Walking Directions"
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 transition-all cursor-pointer"
          >
            <ExternalLink className="w-4 h-4 text-sky-400" />
          </button>

          {onOpenKeyModal && (
            <button
              onClick={onOpenKeyModal}
              title="Google Maps API Key Settings"
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                apiKey
                  ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-300 hover:bg-emerald-900'
                  : 'bg-amber-950/80 border-amber-500/50 text-amber-300 hover:bg-amber-900'
              }`}
            >
              <Key className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Main Geofence Map Viewport */}
      <div className="relative w-full h-[420px] sm:h-[500px] bg-slate-950 overflow-hidden">
        {viewMode === 'google_maps' && apiKey ? (
          <APIProvider apiKey={apiKey}>
            <Map
              center={{ lat: telemetry.latitude, lng: telemetry.longitude }}
              zoom={16}
              mapTypeId="hybrid"
              gestureHandling="greedy"
              disableDefaultUI={false}
              className="w-full h-full"
            >
              <Marker
                position={{
                  lat: config.homeLocation.latitude,
                  lng: config.homeLocation.longitude,
                }}
                title={`Home Base: ${config.homeLocation.label}`}
              />
              <Marker
                position={{
                  lat: telemetry.latitude,
                  lng: telemetry.longitude,
                }}
                title={`${config.patientName} (${Math.round(telemetry.distanceMeters)}m from home)`}
              />
            </Map>
          </APIProvider>
        ) : (
          /* Interactive High-Fidelity Geofence Engine (Vector & Map Tile Canvas) */
          <InteractiveGeofenceEngine
            telemetry={telemetry}
            config={config}
            viewMode={viewMode}
            tileStyle={tileStyle}
            zoomScale={zoomScale}
            panOffset={panOffset}
            onUpdateLocation={onUpdateLocation}
            onOpenKeyModal={onOpenKeyModal}
          />
        )}

        {/* Floating Zoom & Pan Controls */}
        <div className="absolute top-4 left-4 flex flex-col space-y-1.5 z-20">
          <button
            onClick={() => setZoomScale((prev) => Math.min(2.5, prev + 0.25))}
            className="w-9 h-9 bg-slate-900/90 hover:bg-slate-800 text-white rounded-xl border border-slate-700 shadow-lg flex items-center justify-center font-bold text-lg cursor-pointer transition-all active:scale-95"
            title="Zoom In"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoomScale((prev) => Math.max(0.6, prev - 0.25))}
            className="w-9 h-9 bg-slate-900/90 hover:bg-slate-800 text-white rounded-xl border border-slate-700 shadow-lg flex items-center justify-center font-bold text-lg cursor-pointer transition-all active:scale-95"
            title="Zoom Out"
          >
            <Minus className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setZoomScale(1);
              setPanOffset({ x: 0, y: 0 });
            }}
            className="w-9 h-9 bg-slate-900/90 hover:bg-slate-800 text-white rounded-xl border border-slate-700 shadow-lg flex items-center justify-center text-xs font-bold cursor-pointer transition-all active:scale-95"
            title="Reset Map View"
          >
            <RotateCcw className="w-4 h-4 text-emerald-400" />
          </button>
        </div>

        {/* Floating Compass & Coordinate Readout HUD */}
        <div className="absolute bottom-4 left-4 bg-slate-900/90 backdrop-blur-md p-3.5 rounded-2xl border border-slate-700/80 text-xs text-slate-300 shadow-xl space-y-1.5 z-20 pointer-events-none">
          <div className="flex items-center space-x-2 font-mono font-bold text-white">
            <Compass className="w-4 h-4 text-amber-400" />
            <span>
              Heading: {telemetry.bearingText} ({telemetry.bearingDegrees}°)
            </span>
          </div>
          <div className="text-[11px] font-mono text-slate-300">
            Lat: {telemetry.latitude.toFixed(6)} • Lng: {telemetry.longitude.toFixed(6)}
          </div>
          <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-ping" />
            <span>GPS Lock Accuracy: ±{telemetry.accuracy}m</span>
          </div>
        </div>

        {/* Floating Interactive Perimeter Legend & Drag Hint */}
        <div className="absolute top-4 right-4 bg-slate-900/90 backdrop-blur-md p-3 rounded-2xl border border-slate-700 text-xs shadow-xl space-y-2 z-20">
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 rounded-full bg-emerald-500/40 border-2 border-emerald-400 inline-block" />
            <span className="text-slate-200 text-[11px] font-bold">
              Safe Zone: {config.safeRadiusMeters}m
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 rounded-full bg-rose-500/30 border-2 border-rose-400 inline-block" />
            <span className="text-slate-200 text-[11px] font-bold">
              Alert Perimeter: {config.alertRadiusMeters}m
            </span>
          </div>
          <div className="flex items-center space-x-2 pt-1 border-t border-slate-800">
            <span className="w-3 h-3 rounded-full bg-sky-400 inline-block animate-ping" />
            <span className="text-sky-300 text-[11px] font-black">
              {config.patientName} (Live GPS Pulse)
            </span>
          </div>
          <p className="text-[10px] text-amber-300/90 font-medium italic pt-0.5">
            Tip: Click anywhere to simulate elder movement
          </p>
        </div>
      </div>
    </div>
  );
};

/**
 * Interactive Geofence Canvas Engine
 * Displays street/satellite layout, concentric radius boundaries, patient beacon, and click-to-teleport simulation
 */
const InteractiveGeofenceEngine: React.FC<{
  telemetry: CareCompassTelemetry;
  config: CareCompassConfig;
  viewMode: ViewMode;
  tileStyle: TileStyle;
  zoomScale: number;
  panOffset: { x: number; y: number };
  onUpdateLocation?: (lat: number, lng: number) => void;
  onOpenKeyModal?: () => void;
}> = ({
  telemetry,
  config,
  viewMode,
  tileStyle,
  zoomScale,
  panOffset,
  onUpdateLocation,
  onOpenKeyModal,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Scaled coordinate calculation: Home is center (50%, 50%)
  const maxMetersRange = Math.max(900, config.alertRadiusMeters * 1.5) / zoomScale;
  const homeLat = config.homeLocation.latitude;
  const homeLng = config.homeLocation.longitude;

  const deltaLatMeters = (telemetry.latitude - homeLat) * 111139;
  const deltaLngMeters =
    (telemetry.longitude - homeLng) *
    111139 *
    Math.cos((homeLat * Math.PI) / 180);

  // Position relative to canvas center
  const posXPercent = 50 + (deltaLngMeters / maxMetersRange) * 42 + panOffset.x;
  const posYPercent = 50 - (deltaLatMeters / maxMetersRange) * 42 + panOffset.y;

  const safeRadiusPercent = (config.safeRadiusMeters / maxMetersRange) * 42;
  const alertRadiusPercent = (config.alertRadiusMeters / maxMetersRange) * 42;

  // Handle click to set elder location (Live test & simulation)
  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current || !onUpdateLocation) return;
    const rect = containerRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const percentX = (clickX / rect.width) * 100 - 50 - panOffset.x;
    const percentY = (clickY / rect.height) * 100 - 50 - panOffset.y;

    const metersX = (percentX / 42) * maxMetersRange;
    const metersY = -(percentY / 42) * maxMetersRange;

    const newLat = homeLat + metersY / 111139;
    const newLng =
      homeLng + metersX / (111139 * Math.cos((homeLat * Math.PI) / 180));

    onUpdateLocation(newLat, newLng);
  };

  return (
    <div
      ref={containerRef}
      onClick={handleCanvasClick}
      className="relative w-full h-full bg-[#080E1A] flex items-center justify-center select-none overflow-hidden cursor-crosshair"
    >
      {/* High-Contrast Tactical Background Grid */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1.5px,transparent_1.5px)] [background-size:32px_32px] opacity-45" />

      {/* Street & City Vector Overlay Lines */}
      <svg className="absolute inset-0 w-full h-full opacity-30 pointer-events-none">
        <defs>
          <pattern id="city-streets" width="120" height="120" patternUnits="userSpaceOnUse">
            <path d="M 0 60 L 120 60 M 60 0 L 60 120" stroke="#334155" strokeWidth="2" />
            <path d="M 0 30 L 120 30 M 0 90 L 120 90 M 30 0 L 30 120 M 90 0 L 90 120" stroke="#1e293b" strokeWidth="1" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#city-streets)" />
      </svg>

      {/* Tactical Radar HUD Scan Beam */}
      {viewMode === 'radar_hud' && (
        <div className="absolute w-[650px] h-[650px] rounded-full border border-emerald-500/20 pointer-events-none animate-[spin_5s_linear_infinite] bg-[conic-gradient(from_0deg,transparent_0deg,rgba(16,185,129,0.18)_50deg,transparent_51deg)]" />
      )}

      {/* Outer Metric Distance Ring (1000m) */}
      <div
        style={{
          width: `${(1000 / maxMetersRange) * 84}%`,
          height: `${(1000 / maxMetersRange) * 84}%`,
          left: `${50 - (1000 / maxMetersRange) * 42 + panOffset.x}%`,
          top: `${50 - (1000 / maxMetersRange) * 42 + panOffset.y}%`,
        }}
        className="absolute rounded-full border border-slate-700/60 pointer-events-none"
      >
        <span className="absolute bottom-1 left-1/2 -translate-x-1/2 text-[9px] font-mono text-slate-500">
          1000m Outer Range
        </span>
      </div>

      {/* 600m Critical Alert Perimeter Circle (Red/Amber Zone) */}
      <div
        style={{
          width: `${alertRadiusPercent * 2}%`,
          height: `${alertRadiusPercent * 2}%`,
          left: `${50 - alertRadiusPercent + panOffset.x}%`,
          top: `${50 - alertRadiusPercent + panOffset.y}%`,
        }}
        className="absolute rounded-full border-3 border-dashed border-rose-500/80 bg-rose-500/10 pointer-events-none transition-all duration-300 shadow-[0_0_20px_rgba(244,63,94,0.15)]"
      >
        <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[10px] font-mono font-black text-rose-300 bg-slate-950/90 px-2.5 py-0.5 rounded-full border border-rose-500/60 shadow">
          CRITICAL ALERT PERIMETER ({config.alertRadiusMeters}m)
        </span>
      </div>

      {/* 300m Safe Zone Perimeter Circle (Green Zone) */}
      <div
        style={{
          width: `${safeRadiusPercent * 2}%`,
          height: `${safeRadiusPercent * 2}%`,
          left: `${50 - safeRadiusPercent + panOffset.x}%`,
          top: `${50 - safeRadiusPercent + panOffset.y}%`,
        }}
        className="absolute rounded-full border-3 border-emerald-400 bg-emerald-500/15 pointer-events-none transition-all duration-300 shadow-[0_0_25px_rgba(16,185,129,0.2)]"
      >
        <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[10px] font-mono font-black text-emerald-300 bg-slate-950/90 px-2.5 py-0.5 rounded-full border border-emerald-500/60 shadow">
          SAFE HOME ZONE ({config.safeRadiusMeters}m)
        </span>
      </div>

      {/* Historical Breadcrumb GPS Tracking Trail */}
      {telemetry.breadcrumbs && telemetry.breadcrumbs.length > 1 && (
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <polyline
            points={telemetry.breadcrumbs
              .map((b) => {
                const dx = (b.longitude - homeLng) * 111139 * Math.cos((homeLat * Math.PI) / 180);
                const dy = (b.latitude - homeLat) * 111139;
                const px = 50 + (dx / maxMetersRange) * 42 + panOffset.x;
                const py = 50 - (dy / maxMetersRange) * 42 + panOffset.y;
                return `${px}%,${py}%`;
              })
              .join(' ')}
            fill="none"
            stroke="#38bdf8"
            strokeWidth="3.5"
            strokeDasharray="6 4"
            strokeLinecap="round"
            opacity="0.85"
          />
        </svg>
      )}

      {/* Center Home Base Anchor */}
      <div
        style={{
          left: `${50 + panOffset.x}%`,
          top: `${50 + panOffset.y}%`,
        }}
        className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center pointer-events-none z-20"
      >
        <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#FF6321] to-[#EA580C] border-2 border-white shadow-2xl flex items-center justify-center text-white">
          <Home className="w-5 h-5" />
        </div>
        <span className="mt-1.5 text-[11px] font-black text-white bg-slate-950/95 px-2.5 py-0.5 rounded-md border border-slate-700 whitespace-nowrap shadow-lg">
          {config.homeLocation.label} (Home Base)
        </span>
      </div>

      {/* Live Patient Beacon (Dadaji) with Direction Heading Arrow */}
      <div
        style={{
          left: `${Math.min(95, Math.max(5, posXPercent))}%`,
          top: `${Math.min(95, Math.max(5, posYPercent))}%`,
        }}
        className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-30 transition-all duration-300"
      >
        {/* Pulsing Beacon Waves */}
        <div
          className={`absolute w-14 h-14 rounded-full animate-ping pointer-events-none ${
            telemetry.geofenceStatus === 'CRITICAL_BREACH'
              ? 'bg-rose-500/60'
              : telemetry.geofenceStatus === 'WARNING_BORDER'
              ? 'bg-amber-500/50'
              : 'bg-emerald-500/50'
          }`}
        />

        <div
          style={{ transform: `rotate(${telemetry.bearingDegrees}deg)` }}
          className={`w-11 h-11 rounded-2xl border-2 border-white shadow-2xl flex items-center justify-center text-white transition-transform duration-300 ${
            telemetry.geofenceStatus === 'CRITICAL_BREACH'
              ? 'bg-rose-600'
              : telemetry.geofenceStatus === 'WARNING_BORDER'
              ? 'bg-amber-600'
              : 'bg-emerald-600'
          }`}
        >
          <Navigation className="w-6 h-6 -rotate-45" />
        </div>

        <div className="mt-1.5 text-[11px] font-black text-white bg-slate-950/95 px-3 py-1 rounded-lg border border-slate-600 whitespace-nowrap shadow-xl flex items-center gap-1.5">
          <span>{config.patientName}</span>
          <span className="font-mono text-emerald-400 font-extrabold">
            ({Math.round(telemetry.distanceMeters)}m)
          </span>
        </div>
      </div>
    </div>
  );
};
